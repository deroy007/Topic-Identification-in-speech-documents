#!/bin/bash
dirpath=$1
mkdir $dirpath/MALE
mkdir $dirpath/FEMALE

mkdir $dirpath/FEMALE/manika  
mkdir $dirpath/FEMALE/msm
mkdir $dirpath/FEMALE/punam
mkdir $dirpath/FEMALE/rita
mkdir $dirpath/FEMALE/ritwika
mkdir $dirpath/FEMALE/shyamoshree
mkdir $dirpath/FEMALE/suranjana
mkdir $dirpath/FEMALE/tml

mkdir $dirpath/MALE/abd
mkdir $dirpath/MALE/chandan
mkdir $dirpath/MALE/kunal
mkdir $dirpath/MALE/plb
mkdir $dirpath/MALE/sayan
mkdir $dirpath/MALE/sudha
mkdir $dirpath/MALE/swarnendu
mkdir $dirpath/MALE/amitava
mkdir $dirpath/MALE/deb
mkdir $dirpath/MALE/mainak
mkdir $dirpath/MALE/rajashree
mkdir $dirpath/MALE/sm
mkdir $dirpath/MALE/suman
mkdir $dirpath/MALE/xxx
mkdir $dirpath/MALE/bd
mkdir $dirpath/MALE/jit
mkdir $dirpath/MALE/moy
mkdir $dirpath/MALE/samaresh
mkdir $dirpath/MALE/smt
mkdir $dirpath/MALE/suparna
mkdir $dirpath/MALE/chan
mkdir $dirpath/MALE/jyotirmoy
mkdir $dirpath/MALE/padma
mkdir $dirpath/MALE/sandi
mkdir $dirpath/MALE/styabrata
mkdir $dirpath/MALE/suparnakdas

