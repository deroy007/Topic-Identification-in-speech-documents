find ../WAV -depth 2 -type f |
while IFS='' read -r line || [[ -n "$line" ]]; do
    echo "Text read from file: $line"
    echo ../WAVE/$line.wav ../MFCC/$line.mfcc >>htkList
done < "$1"