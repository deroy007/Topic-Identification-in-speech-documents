#!/bin/bash
if [ $# -lt 3 ]
then
	echo "$0 featList gmmPath numMixtures"
	exit
fi

cwd=`readlink -f ../`

fileList=$1
gmmPath=$2
maxMix=$3

protoFile=$cwd/protos/gmmProto39
scpFile=$cwd/misc/gmm.scp
mlfFile=$cwd/misc/gmm.mlf

model=lokendra

rm -f LOG
cp $fileList $scpFile

#Create MLF file
echo "#!MLF!#" > $mlfFile
for file in `cat $fileList|sed 's/mfcc/lab/g'`
do
		echo \"$file\"
		echo $model
		echo .
done >> $mlfFile

echo $model > $cwd/misc/gmmList

######### Calculate Sample Mean and Variance for a 1-Mixture Model #############
rm -rf $gmmPath
mkdir -p $gmmPath/mix_1/final
HCompV  -f 0.01 -m -S $scpFile -o $model -M $gmmPath/mix_1/final $protoFile

########### Reestimate the statistics for multi-mixture model  ################

mix=2
#Number of Mix   (1 2   4  8 16 32 64 128 256 512 1024 2048 4096 8192)
declare -a maxItr=(1 20 20 30 40 40 100 100   15  20   25   30   40   45)
itrCtl=1

while [ $mix -le $maxMix ]
do
	mkdir -p $gmmPath/mix_$mix/0
	mkdir -p $gmmPath/log

	echo -n Mix - $mix:" "

	echo "MU $mix {*.state[2].mix}" > ../misc/hhedCmd
	HHEd -T 1 -H $gmmPath/mix_$((mix/2))/final/$model -M $gmmPath/mix_$mix/0 ../misc/hhedCmd ../misc/gmmList > $gmmPath/log/split_$mix
	
	itr=1
	while [ $itr -le ${maxItr[itrCtl]} ]
	do
		mkdir -p $gmmPath/mix_$mix/$itr
		echo -n $itr " "
		perl HERest.pl -T 3 -w 0 -S $scpFile -I $mlfFile -H $gmmPath/mix_$mix/$((itr-1))/$model -H $gmmPath/mix_1/final/vFloors -M $gmmPath/mix_$mix/$itr ../misc/gmmList > $gmmPath/log/$mix'_'$itr
		itr=$((itr+1))

		if i=$(grep ERROR LOG)
		then
			echo "Errors Occurred while executing HERest -- Exiting for now!"
			echo "See LOG file for details"
			exit
		fi
	done
	mkdir -p $gmmPath/mix_$mix/final
	cp $gmmPath/mix_$mix/${maxItr[itrCtl]}/$model $gmmPath/mix_$mix/final
	mix=$((mix*2))
	itrCtl=$((itrCtl+1))
	echo
done
