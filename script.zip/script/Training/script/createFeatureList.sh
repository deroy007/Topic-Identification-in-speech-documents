#!/bin/bash
wavPath='../../../WAV'
featPath='../../../MFCC'
rm -f  mfccList	
	for file in `ls $wavPath  `
	do
		file1=`echo $file |cut -d'.' -f1  `
		echo $featPath/$file1.mfcc >>mfccList
		
	done
