HERest -T 1 -C configMLRR -J classes -S ../misc/gmm.scp -I ../misc/gmm.mlf -H ../gmmModel/mix_4/final/lokendra -M ../gmmModelNew ../misc/gmmList > logTry
