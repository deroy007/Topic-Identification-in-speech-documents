#!/bin/bash
gmmModel=$1
gmmPath=$2
cat $gmmModel|awk '$1=="<MEAN>"{getline;printf $0 "\n"}' > $gmmPath/meanMFCCDAZ0M.txt
cat $gmmModel|awk '$1=="<VARIANCE>"{getline;printf $0 "\n"}' > $gmmPath/varMFCCDAZ064M.txt
cat $gmmModel|awk '$1=="<MIXTURE>"{printf $3 "\n"}' > $gmmPath/wtMFCCDAZ064M.txt
