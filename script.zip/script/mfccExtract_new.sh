#!/bin/bash

#configFile='mfcc16k.config'
#wavePath = '../WAVE'
#featPath = '../MFCC'
#rm -f  htkList
#for file in 'ls $wavePath'
#do
#	file1=`echo $file  |cut -d'.' -f1 `
#	echo $wavePath/$file1.wav $featPath/$file1.mfcc>>htkList
#done
#while IFS='' read -r line || [[ -n "$line" ]]; do
#    echo "Text read from file: $line"
#    echo ../WAVE/$line.wav ../MFCC/$line.mfcc >>htkList
#done < "$1"

#echo "Exectuting HCOPY ...  "
#HCopy  -C $configFile  -S htkList


wavPath='../WAV'
featPath='../MFCC'
configFile='mfcc16k.config'
rm -f  htkList	
rm -f  spkList
	for file in `ls $wavPath  `
	do
		file1=`echo $file |cut -d'.' -f1  `
		echo $wavPath/$file1.wav $featPath/$file1.mfcc >>htkList
		echo $file1 >>spkList

	done

echo "Exectuting HCOPY ...  "
HCopy  -C $configFile  -S htkList
